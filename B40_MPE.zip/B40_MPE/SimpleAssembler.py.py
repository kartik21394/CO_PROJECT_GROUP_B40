d1={"add":"10000","sub":"10001","mov":"10010","movr":"10100","ld":"10100","st":"10101","mul":"10110","div":"10111","rs":"11000","ls":"11001","xor":"11010","or":"11011","and":"11100","not":"11101","cmp":"11110","jmp":"11111","jlt":"01100","jgt":"01101","je":"01111","hlt":"01010"}
d2={"R0":"000","R1":"001","R2":"010","R3":"011","R4":"100","R5":"101","R6":"110","FLAG":"111"}
rr=["R0","R1","R2","R3","R4","R5","R6","FLAG"]
ta=["add","sub","mul","xor","or","and"]
tb=["mov","rs","ls"]
tc=["mov","div","not","cmp"]
td=["ld","st"]
te=["jmp","jlt","jgt","je"]
tf=["hlt"]
tt=ta+tb+tc+td+te+tf
f1=open("stdin.txt","r")
f2=open("stdout.txt","w")
f2.close()
f2=open("stdout.txt","a")
l1=f1.readlines()
def error(l1):
    e=0
    for i in range(len(l1)):
        z=str(l1[i])
        z=z.split()
        if l1[i]=='\n':
            pass
        elif((z[0] not in tt) and z[0]!="var" and (z[0][-1]!=":")):
            a1=("line no:"+str(i+1)+"illegal opcode or typo error")
            print("line no:",i+1,"illegal opcode or typo error")
            f2.write("\n")
            f2.write(a1)
            e=1
            break
        elif(z[0] in (ta or tb or td)) and (z[1] not in rr): 
            print("line no:"+str(i+1)+"typo in register name1")
            a1="line no:"+str(i+1)+"typo in register name"
            e=1
            f2.write("\n")
            f2.write(a1)
            break
        elif(z[0] in tc ) and (z[2][0]=="$") and  ((z[1] not in rr) ):
            print("line no:"+str(i+1)+"typo in register name2")
            a1="line no:"+str(i+1)+" typo in register name"
            f2.write("\n")
            f2.write(a1)
            e=1
            break 
        elif(z[0] in td ) and ((z[1] not in rr)):
            print("line no:"+str(i+1)+"typo in register name3")
            a1="line no:"+str(i+1)+"typo in register name"
            f2.write("\n")
            f2.write(a1)
            e=1
            break 
        elif(z[0] in ta ) and ((z[2] not in rr) or (z[3] not in rr)):
            print("line no:"+str(i+1)+"typo in register name4")
            a1="line no:"+str(i+1)+"typo in register name"
            f2.write("\n")
            f2.write(a1)
            e=1
            break 
        elif(z[0] in tb) :
            s1=str(z[2][1:])
            s1=int(s1)
            if(s1<=0 or s1>=255):
                print("line no:"+str(i+1)+"illegal immediate value")
                a1="line no:"+"i+1"+"illegal immediate value"
                e=1
                f2.write("\n")
                f2.write(a1)
                break
        elif((z[0] in tf) and i!=(len(l1)-1) ):
            print("line no:"+str(i+1)+"hlt used before last 1")
            a1="line no:"+str(i+1)+"hlt used before last 1"
            f2.write("\n")
            f2.write(a1)
            e=1
            break   
        elif((i ==(len(l1)-1)) and z[0]!="hlt" ):
            print("line no:"+str(i+1),"hlt not present at last")
            a1="line no:"+str(i+1),"hlt not present at last"
            f2.write("\n")
            f2.write(a1)
            e=1
            break
        elif((z[0] in td) or (z[0] in te)):
            s1="var"+" "+z[2]
            if (s1 in l1):
                print("line no:"+str(i+1)+"var not defined")
                a1="line no:"+str(i+1)+"var not defined"
                f2.write("\n")
                f2.write(a1)
                e=1
                break
        elif((z[0] in ta) and ((z[1] or z[2] or z[3])=="FLAG") ):
            print("line no:"+str(i+1)+"illegal use of flag ")
            a1="line no:"+str(i+1)+"illegal use of flag "
            f2.write("\n")
            f2.write(a1)
            e=1
            break
        elif(z[0] in tb) and ((z[1] or z[2])=="FLAG"):
            print("line no:"+str(i+1)+"illegal use of flag ")
            a1="line no:"+str(i+1)+"illegal use of flag "
            f2.write("\n")
            f2.write(a1)
            e=1
            break
        elif(z[0] in tc) and (z[1]!="mov") and (z[2] or z[1]=="FLAG"):
            print("line no:"+str(i+1)+"illegal use of flag ")
            a1="line no:"+str(i+1)+"illegal use of flag "
            f2.write("\n")
            f2.write(a1)
            e=1
            break
        elif((z[0] in td) and (z[1] or z[2])=="FLAG"):
            print("line no:"+str(i+1)+"illegal use of flag ")
            a1="line no:"+str(i+1)+"illegal use of flag "
            f2.write("\n")
            f2.write(a1)
            e=1
            break
        elif((z[0] in te) and (z[1] )=="FLAG"):
            print("line no:"+str(i+1)+"illegal use of flag ")
            a1="line no:"+str(i+1)+"illegal use of flag "
            f2.write("\n")
            f2.write(a1)
            e=1
            break
    return e           

def cont(l1,c1):
    count=0
    for i in range(len(l1)):
        z1=str(l1[i])
        z1=z1.split()
        if l1[i]=='\n':
            pass
        elif z1[0] in tt:
            count=count+1
    for i in range(len(l1)):
        z1=str(l1[i])
        z1=z1.split()
        if l1[i]=='\n':
            pass
        elif (z1[0] =="var") and (z1[1]!=c1):
            count=count+1
        elif (z1[0]=="var") and (z1[1]==c1) :
            break
    return count
def op(l1):
    for i in range(len(l1)):
        z=str(l1[i])
        z=z.split()
        if l1[i]=='\n':
            pass
        elif(z[0] in ta):
            m1=d1[z[0]]+"00"+d2[z[1]]+d2[z[2]]+d2[z[3]]
            print(m1)
            f2.write("\n")
            f2.write(m1)
        elif(z[0] in tb and z[2][0]=="$"):
            z1=str(z[2][1:])
            z2=len(z1)
            z1=int(z1)
            z3=bin(z1)[2:]
            z3=str(z3)
            z4=len(z3)
            m1=d1[z[0]]+d2[z[1]]+"0"*(8-len(z3))+z3
            print(m1)
            f2.write("\n")
            f2.write(m1)
        elif(z[0] in tc and z[2][0]!="$"):
            m1=d1[z[0]]+"00000"+d2[z[1]]+d2[z[2]]
            print(m1)
            f2.write("\n")
            f2.write(m1)
        elif(z[0] in tf):
            m1=d1[z[0]]+"0"*11
            print(m1)
            f2.write("\n")
            f2.write(m1)
        elif(z[0] in td):
            c1=z[2]   
            c2=cont(l1,c1)
            z3=bin(c2)[2:]
            m1=d1[z[0]]+d2[z[1]]+"0"*(8-len(z3))+z3
            print(m1)
            f2.write("\n")
            f2.write(m1)
        elif(z[0] in te):
            c1=z[2]   
            c2=cont(l1,c1)
            z3=bin(c2)[2:]
            m1=d1[z[0]]+"000"+"0"*(8-len(z3))+z3
            print(m1)
            f2.write("\n")
            f2.write(m1)
        elif(z[0][len(z[0])-1]==":"):
            pass 
if(error(l1)!=1):
    op(l1)
